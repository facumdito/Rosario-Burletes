"""
test_dataset.py — Verifica el dataset completo y ejercita todos los endpoints.

Correr:
    pytest backend/tests/test_dataset.py -v
"""

import pytest


# ─────────────────────────────────────────────
# HEALTH
# ─────────────────────────────────────────────

def test_root(client):
    r = client.get("/")
    assert r.status_code == 200
    assert r.json()["name"] == "Paraná API"


def test_health(client):
    r = client.get("/health")
    assert r.json() == {"status": "ok"}


# ─────────────────────────────────────────────
# AUTH
# ─────────────────────────────────────────────

def test_signup(client):
    r = client.post("/api/v1/auth/signup", json={
        "email": "nuevo@empresa.com",
        "password": "pass1234",
        "full_name": "Nuevo Usuario",
        "tenant_name": "Nueva Empresa SA",
    })
    assert r.status_code == 200
    assert "access_token" in r.json()


def test_login_ok(client, user):
    r = client.post("/api/v1/auth/login", json={
        "email": "admin@testpyme.com", "password": "test1234"
    })
    assert r.status_code == 200
    assert r.json()["email"] == "admin@testpyme.com"


def test_login_wrong_password(client, user):
    r = client.post("/api/v1/auth/login", json={
        "email": "admin@testpyme.com", "password": "WRONG"
    })
    assert r.status_code == 401


def test_me(client, auth_headers):
    r = client.get("/api/v1/auth/me", headers=auth_headers)
    assert r.status_code == 200
    assert r.json()["email"] == "admin@testpyme.com"


def test_me_sin_token(client):
    r = client.get("/api/v1/auth/me")
    assert r.status_code == 401


# ─────────────────────────────────────────────
# CLIENTES
# ─────────────────────────────────────────────

def test_list_customers(client, auth_headers, customers):
    r = client.get("/api/v1/customers", headers=auth_headers)
    assert r.status_code == 200
    data = r.json()
    assert len(data) == 8

    nombres = {c["name"] for c in data}
    assert "Paladini SA" in nombres
    assert "Moroso Industrias SA" in nombres


def test_customer_search_por_nombre(client, auth_headers, customers):
    r = client.get("/api/v1/customers?q=Paladini", headers=auth_headers)
    assert r.status_code == 200
    assert len(r.json()) == 1
    assert r.json()[0]["name"] == "Paladini SA"


def test_customer_search_por_cuit(client, auth_headers, customers):
    r = client.get("/api/v1/customers?q=30-50001234-1", headers=auth_headers)
    assert r.status_code == 200
    assert r.json()[0]["tax_id"] == "30-50001234-1"


def test_customer_sin_cuit_ni_email(client, auth_headers, customers):
    """Cliente ocasional sin datos completos — no debe crashear."""
    r = client.get("/api/v1/customers?q=Ocasional", headers=auth_headers)
    assert r.status_code == 200
    c = r.json()[0]
    assert c["tax_id"] is None
    assert c["email"] is None


def test_crear_customer(client, auth_headers, tenant):
    r = client.post("/api/v1/customers", headers=auth_headers, json={
        "name": "Nuevo Cliente SRL",
        "tax_id": "30-12345678-0",
        "email": "nuevo@cliente.com",
        "city": "Córdoba",
    })
    assert r.status_code == 201
    assert r.json()["name"] == "Nuevo Cliente SRL"


def test_get_customer_by_id(client, auth_headers, customers):
    cid = customers[0].id
    r = client.get(f"/api/v1/customers/{cid}", headers=auth_headers)
    assert r.status_code == 200
    assert r.json()["name"] == "Paladini SA"


def test_get_customer_inexistente(client, auth_headers):
    r = client.get("/api/v1/customers/999999", headers=auth_headers)
    assert r.status_code == 404


def test_update_customer(client, auth_headers, customers):
    cid = customers[0].id
    r = client.put(f"/api/v1/customers/{cid}", headers=auth_headers, json={
        "name": "Paladini SA (actualizado)",
        "credit_limit": 600_000,
    })
    assert r.status_code == 200
    assert r.json()["name"] == "Paladini SA (actualizado)"


def test_delete_customer(client, auth_headers, customers):
    cid = customers[5].id  # Flexiglass
    r = client.delete(f"/api/v1/customers/{cid}", headers=auth_headers)
    assert r.status_code == 204


# ─────────────────────────────────────────────
# PRODUCTOS
# ─────────────────────────────────────────────

def test_list_products(client, auth_headers, products):
    r = client.get("/api/v1/products", headers=auth_headers)
    assert r.status_code == 200
    assert len(r.json()) == 20


def test_products_stock_critico(client, auth_headers, products):
    """BUR-SIL-40, TIR-3X50 y PER-U-12 tienen stock <= stock_min."""
    r = client.get("/api/v1/products", headers=auth_headers)
    criticos = [p for p in r.json() if p["stock"] <= p["stock_min"]]
    skus_criticos = {p["sku"] for p in criticos}
    assert "BUR-SIL-40" in skus_criticos
    assert "TIR-3X50" in skus_criticos
    assert "PER-U-12" in skus_criticos  # sin stock


def test_product_search_por_nombre(client, auth_headers, products):
    r = client.get("/api/v1/products?q=EPDM", headers=auth_headers)
    assert r.status_code == 200
    skus = [p["sku"] for p in r.json()]
    assert "BUR-EPDM-31" in skus


def test_product_sin_precio(client, auth_headers, products):
    r = client.get("/api/v1/products?q=PROTOTIPO", headers=auth_headers)
    assert r.status_code == 200
    p = r.json()[0]
    assert p["price"] == 0
    assert p["material"] is None


def test_crear_product(client, auth_headers, tenant):
    r = client.post("/api/v1/products", headers=auth_headers, json={
        "sku": "TEST-001",
        "name": "Producto de test",
        "material": "EPDM",
        "hardness": 70,
        "unit": "mt",
        "cost": 1000,
        "price": 1600,
        "stock": 100,
        "stock_min": 20,
    })
    assert r.status_code == 201
    assert r.json()["sku"] == "TEST-001"


# ─────────────────────────────────────────────
# FACTURAS
# ─────────────────────────────────────────────

def test_list_invoices(client, auth_headers, invoices):
    r = client.get("/api/v1/invoices", headers=auth_headers)
    assert r.status_code == 200
    assert len(r.json()) == 30


def test_invoices_by_status_overdue(client, auth_headers, invoices):
    r = client.get("/api/v1/invoices?status=overdue", headers=auth_headers)
    assert r.status_code == 200
    assert all(inv["status"] == "overdue" for inv in r.json())


def test_invoices_by_status_draft(client, auth_headers, invoices):
    r = client.get("/api/v1/invoices?status=draft", headers=auth_headers)
    assert r.status_code == 200
    assert all(inv["status"] == "draft" for inv in r.json())
    assert len(r.json()) > 0


def test_crear_invoice_draft(client, auth_headers, customers, products):
    r = client.post("/api/v1/invoices", headers=auth_headers, json={
        "customer_id": customers[0].id,
        "invoice_type": "A",
        "items": [
            {"product_id": products[0].id, "description": "Burlete EPDM 31mm",
             "quantity": 50, "unit_price": 29000},
        ]
    })
    assert r.status_code == 201
    data = r.json()
    assert data["status"] == "draft"
    assert data["subtotal"] == 1_450_000
    assert data["tax"] == 304_500   # 21% IVA
    assert data["total"] == 1_754_500


def test_emitir_invoice(client, auth_headers, invoices):
    draft = next(inv for inv in invoices if inv.status == "draft")
    r = client.post(f"/api/v1/invoices/{draft.id}/issue", headers=auth_headers)
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "issued"
    assert data["afip_cae"] is not None


def test_emitir_invoice_ya_emitida(client, auth_headers, invoices):
    issued = next(inv for inv in invoices if inv.status == "issued")
    r = client.post(f"/api/v1/invoices/{issued.id}/issue", headers=auth_headers)
    assert r.status_code == 400


def test_registrar_pago(client, auth_headers, invoices):
    issued = next(inv for inv in invoices if inv.status == "issued")
    r = client.post(f"/api/v1/invoices/{issued.id}/payments", headers=auth_headers, json={
        "amount": float(issued.total),
        "method": "transfer",
        "reference": "REF-TEST-001",
    })
    assert r.status_code == 201
    assert r.json()["status"] == "paid"


def test_invoice_cliente_invalido(client, auth_headers, products):
    r = client.post("/api/v1/invoices", headers=auth_headers, json={
        "customer_id": 999999,
        "invoice_type": "B",
        "items": [{"description": "Algo", "quantity": 1, "unit_price": 100}]
    })
    assert r.status_code == 400


# ─────────────────────────────────────────────
# PRODUCCIÓN
# ─────────────────────────────────────────────

def test_list_orders(client, auth_headers, production_orders):
    r = client.get("/api/v1/production/orders", headers=auth_headers)
    assert r.status_code == 200
    assert len(r.json()) == 8


def test_orders_por_status(client, auth_headers, production_orders):
    r = client.get("/api/v1/production/orders?status=done", headers=auth_headers)
    assert r.status_code == 200
    assert all(o["status"] == "done" for o in r.json())


def test_order_avanzar_etapa(client, auth_headers, production_orders):
    pending = next(o for o in production_orders if o.status == "pending")
    r = client.post(f"/api/v1/production/orders/{pending.id}/stage", headers=auth_headers, json={
        "stage": "extrusion",
        "action": "start",
        "operator": "Test Operario",
    })
    assert r.status_code == 200
    assert r.json()["status"] == "in_progress"


def test_crear_order(client, auth_headers, customers, products):
    r = client.post("/api/v1/production/orders", headers=auth_headers, json={
        "customer_id": customers[0].id,
        "product_id": products[0].id,
        "description": "Orden de test",
        "quantity": 100,
    })
    assert r.status_code == 201
    data = r.json()
    assert data["status"] == "pending"
    assert len(data["stages"]) == 6  # las 6 etapas creadas vacías


# ─────────────────────────────────────────────
# WHATSAPP
# ─────────────────────────────────────────────

def test_list_conversations(client, auth_headers, whatsapp_conversations):
    r = client.get("/api/v1/whatsapp/conversations", headers=auth_headers)
    assert r.status_code == 200
    assert len(r.json()) == 5


def test_conversation_abierta(client, auth_headers, whatsapp_conversations):
    r = client.get("/api/v1/whatsapp/conversations?status=open", headers=auth_headers)
    assert r.status_code == 200
    assert all(c["status"] == "open" for c in r.json())


def test_conversation_derivada_a_humano(client, auth_headers, whatsapp_conversations):
    r = client.get("/api/v1/whatsapp/conversations?status=human", headers=auth_headers)
    assert r.status_code == 200
    assert len(r.json()) == 1
    assert r.json()[0]["contact_name"] == "Comasa SA"


def test_simulate_incoming(client, auth_headers, tenant):
    """Simula mensaje entrante — sin clave API funciona en modo demo."""
    r = client.post("/api/v1/whatsapp/simulate", headers=auth_headers, json={
        "phone": "+5493415999000",
        "content": "Hola, necesito precio por burlete EPDM 31mm",
    })
    assert r.status_code == 200
    assert r.json()["direction"] == "inbound"


# ─────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────

def test_dashboard_stats(client, auth_headers, full_dataset):
    r = client.get("/api/v1/dashboard/stats", headers=auth_headers)
    assert r.status_code == 200
    data = r.json()
    campos = ["cash_today", "invoices_this_month", "pending_collection",
              "overdue_count", "whatsapp_open", "production_active",
              "top_customers", "monthly_sales"]
    for campo in campos:
        assert campo in data, f"Falta campo: {campo}"

    assert data["overdue_count"] >= 4          # hay varias overdue en el dataset
    assert data["production_active"] >= 2      # hay órdenes pending/in_progress
    assert data["whatsapp_open"] >= 2          # hay convs abiertas
    assert len(data["monthly_sales"]) == 6     # 6 meses siempre
