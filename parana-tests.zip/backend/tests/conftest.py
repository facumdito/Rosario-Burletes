"""
conftest.py — Fixtures completos para Paraná.

Requiere:
    pip install pytest pytest-asyncio httpx --break-system-packages

Variables de entorno (opcional, usa SQLite en memoria si no hay Postgres):
    TEST_DATABASE_URL=postgresql+psycopg://parana:parana@localhost:5432/parana_test
"""

import os
from collections.abc import Generator
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker

# ── Motor de test (SQLite en memoria por default, Postgres si hay env var) ──
TEST_DB_URL = os.getenv(
    "TEST_DATABASE_URL",
    "sqlite:///./test_parana.db",
)

# pgvector no existe en SQLite: se usa el mock si no hay Postgres
_USE_PG = TEST_DB_URL.startswith("postgresql")

engine = create_engine(
    TEST_DB_URL,
    connect_args={} if _USE_PG else {"check_same_thread": False},
)
TestingSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# ─────────────────────────────────────────────
# 1. SETUP / TEARDOWN DE BASE DE DATOS
# ─────────────────────────────────────────────

@pytest.fixture(scope="session", autouse=True)
def setup_db():
    """Crea tablas una vez por sesión, las borra al final."""
    from app.core.database import Base
    from app import models  # noqa: F401 — registra todos los modelos

    if _USE_PG:
        with engine.begin() as conn:
            conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))

    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def db() -> Generator[Session, None, None]:
    """Sesión de DB por test; hace rollback al finalizar."""
    connection = engine.connect()
    transaction = connection.begin()
    session = Session(bind=connection)
    yield session
    session.close()
    transaction.rollback()
    connection.close()


# ─────────────────────────────────────────────
# 2. APP / CLIENT
# ─────────────────────────────────────────────

@pytest.fixture()
def client(db: Session) -> TestClient:
    """TestClient con DB sobreescrita por la sesión de test."""
    from app.main import app
    from app.core.database import get_db

    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


# ─────────────────────────────────────────────
# 3. DATOS BASE
# ─────────────────────────────────────────────

@pytest.fixture()
def tenant(db: Session):
    from app.models import Tenant
    t = Tenant(name="Test PyME SA", slug="test-pyme-sa", country="AR", tax_id="30-99999999-1", plan="pro")
    db.add(t)
    db.flush()
    return t


@pytest.fixture()
def user(db: Session, tenant):
    from app.models import User
    from app.core.security import hash_password
    u = User(
        tenant_id=tenant.id,
        email="admin@testpyme.com",
        hashed_password=hash_password("test1234"),
        full_name="Admin Test",
        role="owner",
    )
    db.add(u)
    db.flush()
    return u


@pytest.fixture()
def auth_headers(client: TestClient, user) -> dict:
    """Bearer token válido para el usuario de test."""
    r = client.post("/api/v1/auth/login", json={"email": "admin@testpyme.com", "password": "test1234"})
    assert r.status_code == 200
    token = r.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


# ─────────────────────────────────────────────
# 4. CLIENTES  (8 perfiles distintos)
# ─────────────────────────────────────────────

CUSTOMER_DATA = [
    {
        "name": "Paladini SA",
        "tax_id": "30-50001234-1",
        "email": "compras@paladini.com.ar",
        "phone": "+5493415550101",
        "whatsapp": "+5493415550101",
        "city": "Villa Gobernador Gálvez",
        "credit_limit": 500_000,
        "tags": "B2B,alimentos,grande",
    },
    {
        "name": "Brafh Industrias SA",
        "tax_id": "30-52309876-5",
        "email": "compras@brafh.com.ar",
        "phone": "+5493415550102",
        "whatsapp": "+5493415550102",
        "city": "Rosario",
        "credit_limit": 300_000,
        "tags": "B2B,metalúrgica",
    },
    {
        "name": "Comasa SA",
        "tax_id": "30-60012345-7",
        "email": "admin@comasa.com.ar",
        "phone": "+5493415550103",
        "whatsapp": "+5493415550103",
        "city": "Rosario",
        "credit_limit": 200_000,
        "tags": "B2B",
    },
    {
        "name": "Plasbe SRL",
        "tax_id": "30-54345678-9",
        "email": "info@plasbe.com.ar",
        "phone": "+5493415550104",
        "whatsapp": None,
        "city": "Funes",
        "credit_limit": 100_000,
        "tags": "B2B,plásticos",
    },
    {
        "name": "La Goma Argentina SRL",
        "tax_id": "30-70123456-2",
        "email": "ventas@lagomaarg.com",
        "phone": "+5493415550105",
        "whatsapp": "+5493415550105",
        "city": "Rosario",
        "credit_limit": 250_000,
        "tags": "B2B,caucho",
    },
    {
        "name": "Flexiglass SRL",
        "tax_id": "30-71234567-3",
        "email": "contacto@flexiglass.com.ar",
        "phone": "+5493415550106",
        "whatsapp": None,
        "city": "Granadero Baigorria",
        "credit_limit": 80_000,
        "tags": "B2B",
    },
    {
        # cliente sin CUIT ni email — caso borde
        "name": "Cliente Ocasional SN",
        "tax_id": None,
        "email": None,
        "phone": "+5493415559999",
        "whatsapp": None,
        "city": None,
        "credit_limit": 0,
        "tags": None,
    },
    {
        # cliente con deuda vencida — para probar cobranzas
        "name": "Moroso Industrias SA",
        "tax_id": "30-88888888-8",
        "email": "moroso@industrias.com.ar",
        "phone": "+5493415550108",
        "whatsapp": "+5493415550108",
        "city": "Buenos Aires",
        "credit_limit": 50_000,
        "tags": "B2B,riesgo",
    },
]


@pytest.fixture()
def customers(db: Session, tenant):
    from app.models import Customer
    objs = []
    for d in CUSTOMER_DATA:
        c = Customer(tenant_id=tenant.id, **d)
        db.add(c)
        objs.append(c)
    db.flush()
    return objs


# ─────────────────────────────────────────────
# 5. PRODUCTOS  (20 SKUs con variantes realistas)
# ─────────────────────────────────────────────

PRODUCT_DATA = [
    # Burletes EPDM
    {"sku": "BUR-EPDM-31", "name": "BURLETE EPDM ALT 31MM", "material": "EPDM", "hardness": 70,
     "unit": "mt", "cost": 18_000, "price": 29_000, "stock": 300, "stock_min": 50, "category": "Burlete"},
    {"sku": "BUR-EPDM-45", "name": "BURLETE EPDM ALT 45MM", "material": "EPDM", "hardness": 70,
     "unit": "mt", "cost": 24_000, "price": 38_000, "stock": 150, "stock_min": 30, "category": "Burlete"},
    {"sku": "BUR-EPDM-60", "name": "BURLETE EPDM ALT 60MM", "material": "EPDM", "hardness": 65,
     "unit": "mt", "cost": 31_000, "price": 49_000, "stock": 80, "stock_min": 20, "category": "Burlete"},

    # Burletes Silicona
    {"sku": "BUR-SIL-25", "name": "BURLETE SILICONA 25MM ROJO", "material": "Silicona", "hardness": 50,
     "unit": "mt", "cost": 22_000, "price": 35_000, "stock": 200, "stock_min": 40, "category": "Burlete"},
    {"sku": "BUR-SIL-40", "name": "BURLETE SILICONA 40MM BLANCO", "material": "Silicona", "hardness": 55,
     "unit": "mt", "cost": 28_000, "price": 44_000, "stock": 10, "stock_min": 30, "category": "Burlete"},  # stock crítico

    # Carros mantenedores
    {"sku": "BUR-CAR-615", "name": "BURLETE CARRO MANT 615x685MM", "material": "Silicona", "hardness": 60,
     "unit": "un", "cost": 52_000, "price": 79_600, "stock": 45, "stock_min": 10, "category": "Carro"},
    {"sku": "BUR-CAR-720", "name": "BURLETE CARRO MANT 720x680MM", "material": "Silicona", "hardness": 60,
     "unit": "un", "cost": 55_000, "price": 84_200, "stock": 30, "stock_min": 10, "category": "Carro"},

    # Perfiles U
    {"sku": "PER-U-8", "name": "PERFIL U INT 8MM CAUCHO NATURAL", "material": "Caucho natural", "hardness": 70,
     "unit": "mt", "cost": 3_000, "price": 4_800, "stock": 500, "stock_min": 100, "category": "Perfil"},
    {"sku": "PER-U-12", "name": "PERFIL U INT 12MM CAUCHO NATURAL", "material": "Caucho natural", "hardness": 70,
     "unit": "mt", "cost": 4_200, "price": 6_700, "stock": 0, "stock_min": 50, "category": "Perfil"},  # sin stock
    {"sku": "PER-U-16", "name": "PERFIL U INT 16MM NEOPRENO", "material": "Neopreno", "hardness": 65,
     "unit": "mt", "cost": 5_500, "price": 8_800, "stock": 220, "stock_min": 40, "category": "Perfil"},

    # Cuerdas
    {"sku": "CUE-3-60", "name": "CUERDA 3x60 SILICONA RV", "material": "Silicona", "hardness": 50,
     "unit": "mt", "cost": 1_500, "price": 2_400, "stock": 800, "stock_min": 150, "category": "Cuerda"},
    {"sku": "CUE-5-60", "name": "CUERDA 5x60 NBR", "material": "NBR", "hardness": 65,
     "unit": "mt", "cost": 2_200, "price": 3_500, "stock": 600, "stock_min": 120, "category": "Cuerda"},
    {"sku": "CUE-8-40", "name": "CUERDA 8x40 EPDM", "material": "EPDM", "hardness": 60,
     "unit": "mt", "cost": 3_100, "price": 5_000, "stock": 350, "stock_min": 80, "category": "Cuerda"},

    # Sellos
    {"sku": "SEL-32-18", "name": "SELLO P/FAB DISC 32/18 SILICONA NARANJA", "material": "Silicona", "hardness": 50,
     "unit": "un", "cost": 1_200, "price": 1_850, "stock": 1_200, "stock_min": 200, "category": "Sello"},
    {"sku": "SEL-50-25", "name": "SELLO P/FAB DISC 50/25 NBR", "material": "NBR", "hardness": 70,
     "unit": "un", "cost": 1_800, "price": 2_900, "stock": 800, "stock_min": 150, "category": "Sello"},

    # Perfiles E
    {"sku": "PER-E-5882", "name": "PERFIL TIPO E USO GENERAL SILICONA", "material": "Silicona", "hardness": 60,
     "unit": "mt", "cost": 2_100, "price": 3_400, "stock": 420, "stock_min": 60, "category": "Perfil"},
    {"sku": "PER-E-NBR-5882", "name": "PERFIL TIPO E NBR 65 SH", "material": "NBR", "hardness": 65,
     "unit": "mt", "cost": 2_400, "price": 3_900, "stock": 180, "stock_min": 40, "category": "Perfil"},

    # Tiras planas
    {"sku": "TIR-2X30", "name": "TIRA PLANA 2x30MM EPDM", "material": "EPDM", "hardness": 60,
     "unit": "mt", "cost": 2_600, "price": 4_200, "stock": 300, "stock_min": 50, "category": "Tira"},
    {"sku": "TIR-3X50", "name": "TIRA PLANA 3x50MM SILICONA", "material": "Silicona", "hardness": 55,
     "unit": "mt", "cost": 4_100, "price": 6_600, "stock": 5, "stock_min": 40, "category": "Tira"},  # stock crítico

    # Sin precio — caso borde
    {"sku": "PROT-NUEVO", "name": "PROTOTIPO EN DESARROLLO", "material": None, "hardness": None,
     "unit": "un", "cost": 0, "price": 0, "stock": 3, "stock_min": 0, "category": None},
]


@pytest.fixture()
def products(db: Session, tenant):
    from app.models import Product
    objs = []
    for d in PRODUCT_DATA:
        p = Product(tenant_id=tenant.id, description=d.get("name"), **d)
        db.add(p)
        objs.append(p)
    db.flush()
    return objs


# ─────────────────────────────────────────────
# 6. FACTURAS  (30: draft / issued / paid / overdue)
# ─────────────────────────────────────────────

@pytest.fixture()
def invoices(db: Session, tenant, customers, products):
    from app.models import Invoice, InvoiceItem, Payment
    today = date.today()
    objs = []
    scenarios = [
        # (customer_idx, type, status, issue_offset_days, items_idx, paid)
        (0, "A", "issued",  -5,  [0, 1],     False),
        (0, "A", "paid",   -30,  [2, 3],     True),
        (0, "A", "overdue",-45,  [0],        False),
        (1, "B", "draft",    0,  [4, 5],     False),
        (1, "B", "issued", -10,  [6],        False),
        (1, "B", "paid",   -20,  [7, 8],     True),
        (2, "B", "overdue",-60,  [9],        False),
        (2, "A", "issued", -15,  [10, 11],   False),
        (3, "C", "paid",   -10,  [12],       True),
        (3, "B", "draft",    0,  [13, 14],   False),
        (4, "A", "issued",  -3,  [15],       False),
        (4, "A", "paid",   -40,  [16, 17],   True),
        (5, "B", "overdue",-50,  [18],       False),
        (6, "B", "issued", -12,  [19],       False),
        (7, "A", "overdue",-70,  [0, 19],    False),
        # facturas del mes actual
        (0, "A", "issued",  -1,  [1, 2],     False),
        (1, "B", "paid",    -2,  [3],        True),
        (2, "A", "draft",    0,  [4, 5, 6],  False),
        (3, "B", "issued",  -3,  [7],        False),
        (4, "A", "issued",  -1,  [8, 9],     False),
        # facturas antiguas (hace 3-6 meses)
        (0, "A", "paid",  -90,  [0, 1, 2],  True),
        (1, "B", "paid",  -95,  [3, 4],     True),
        (2, "A", "paid", -100,  [5],        True),
        (3, "B", "paid", -120,  [6, 7],     True),
        (4, "A", "paid", -150,  [8, 9],     True),
        (5, "B", "paid", -160,  [10],       True),
        (0, "A", "paid", -180,  [11, 12],   True),
        (1, "B", "paid", -185,  [13],       True),
        (2, "A", "issued",-88,  [14, 15],   False),
        (3, "B", "overdue",-95, [16],       False),
    ]
    for idx, (ci, inv_type, status, offset, prod_idxs, paid) in enumerate(scenarios):
        issue = today + timedelta(days=offset)
        due = issue + timedelta(days=30)
        subtotal = 0.0
        items = []
        for pi in prod_idxs:
            p = products[pi % len(products)]
            qty = 10.0
            total = round(qty * float(p.price), 2)
            subtotal += total
            items.append(InvoiceItem(
                product_id=p.id,
                description=p.name,
                quantity=qty,
                unit_price=float(p.price),
                total=total,
            ))
        tax = round(subtotal * 0.21, 2) if inv_type in ("A", "B") else 0
        inv = Invoice(
            tenant_id=tenant.id,
            customer_id=customers[ci].id,
            number=f"0001-{idx + 1:08d}",
            invoice_type=inv_type,
            issue_date=issue,
            due_date=due,
            subtotal=subtotal,
            tax=tax,
            total=round(subtotal + tax, 2),
            status=status,
            afip_cae=f"7423{idx:010d}" if status != "draft" else None,
            afip_cae_due=issue + timedelta(days=10) if status != "draft" else None,
        )
        inv.items = items
        if paid:
            inv.payments = [Payment(
                amount=inv.total,
                method="transfer",
                reference=f"PAY-{idx + 1}",
                paid_at=issue + timedelta(days=15),
            )]
        db.add(inv)
        objs.append(inv)
    db.flush()
    return objs


# ─────────────────────────────────────────────
# 7. ÓRDENES DE PRODUCCIÓN  (8 órdenes en distintas etapas)
# ─────────────────────────────────────────────

STAGES = ["extrusion", "prensa", "postcurado", "control", "embalaje", "tunel"]


@pytest.fixture()
def production_orders(db: Session, tenant, customers, products):
    from datetime import datetime
    from app.models import ProductionOrder, ProductionStage

    scenarios = [
        # (description, qty, customer_idx, prod_idx, stages_done, status)
        ("Burlete EPDM 31mm · Paladini",     500, 0, 0,  0, "pending"),
        ("Perfil U 8mm · Brafh",             300, 1, 7,  2, "in_progress"),
        ("Cuerda 3x60 Silicona · Comasa",    800, 2, 10, 4, "in_progress"),
        ("Sello Disc 32/18 · Plasbe",       1200, 3, 13, 6, "done"),
        ("Carro Mantenedor 615 · La Goma",    20, 4, 5,  1, "in_progress"),
        ("Tira Plana 2x30 · Flexiglass",     200, 5, 17, 3, "in_progress"),
        ("Prototipo nuevo · Paladini",          5, 0, 19, 0, "pending"),
        ("Burlete Silicona 40mm · Brafh",    150, 1, 3,  5, "done"),
    ]
    now = datetime.utcnow()
    objs = []
    for i, (desc, qty, ci, pi, stages_done, status) in enumerate(scenarios):
        order = ProductionOrder(
            tenant_id=tenant.id,
            number=f"OP-{i + 1:06d}",
            customer_id=customers[ci].id,
            product_id=products[pi % len(products)].id,
            description=desc,
            quantity=qty,
            status=status,
            current_stage=STAGES[min(stages_done, len(STAGES) - 1)],
        )
        for idx, s in enumerate(STAGES):
            stage = ProductionStage(stage=s)
            if idx < stages_done:
                stage.started_at = now - timedelta(hours=(stages_done - idx) * 4 + 2)
                stage.finished_at = now - timedelta(hours=(stages_done - idx) * 4)
                stage.operator = ["Ana Silva", "Juan López", "Mario Pérez"][idx % 3]
            elif idx == stages_done and stages_done < len(STAGES) and status == "in_progress":
                stage.started_at = now - timedelta(hours=1)
                stage.operator = "Ana Silva"
            order.stages.append(stage)
        db.add(order)
        objs.append(order)
    db.flush()
    return objs


# ─────────────────────────────────────────────
# 8. CONVERSACIONES WHATSAPP  (5 conversaciones)
# ─────────────────────────────────────────────

WA_SCRIPTS = [
    # (phone, contact, status, ai_enabled, messages)
    (
        "+5493415550101", "Paladini SA", "open", True,
        [
            ("inbound",  "customer", "Hola, ¿tenés burlete EPDM 31mm en stock?"),
            ("outbound", "ai",       "Hola! Sí, tenemos 300 metros a $29.000/mt + IVA. ¿Armamos pedido?"),
            ("inbound",  "customer", "Dale, 50 metros para el lunes."),
            ("outbound", "ai",       "Perfecto, anotado. Te paso confirmación y link de pago."),
        ]
    ),
    (
        "+5493415550102", "Brafh Industrias", "open", True,
        [
            ("inbound",  "customer", "Buen día, necesito precio por perfil U 8mm"),
            ("outbound", "ai",       "Buenos días! Perfil U 8mm caucho natural: $4.800/mt + IVA. ¿Cantidad?"),
        ]
    ),
    (
        "+5493415550103", "Comasa SA", "human", False,
        [
            ("inbound",  "customer", "Tienen un error en la última factura, el precio no es el acordado"),
            ("outbound", "ai",       "Entiendo, voy a pasarte con nuestra administración para revisarlo."),
            ("outbound", "human",    "Hola! Ya revisé, fue un error nuestro. Emitimos nota de crédito."),
        ]
    ),
    (
        "+5493415559999", "Consulta nueva", "open", True,
        [
            ("inbound",  "customer", "Hola, llegué por recomendación. ¿Hacen burletes para hornos?"),
            ("outbound", "ai",       "Hola! Sí, trabajamos con silicona de alta temperatura. ¿Qué medidas necesitás?"),
        ]
    ),
    (
        "+5493415550108", "Moroso Industrias", "closed", False,
        [
            ("inbound",  "customer", "Cuando pueden me mandan el número de cuenta para pagar"),
            ("outbound", "human",    "Hola, te pasamos los datos: Banco Galicia CBU 00700415..."),
            ("inbound",  "customer", "Listo, ya transferí."),
        ]
    ),
]


@pytest.fixture()
def whatsapp_conversations(db: Session, tenant, customers):
    from datetime import datetime
    from app.models import WhatsAppConversation, WhatsAppMessage

    # mapa de teléfono → customer
    phone_to_customer = {c.whatsapp: c for c in customers if c.whatsapp}
    now = datetime.utcnow()
    objs = []
    for phone, contact, status, ai_enabled, messages in WA_SCRIPTS:
        customer = phone_to_customer.get(phone)
        conv = WhatsAppConversation(
            tenant_id=tenant.id,
            customer_id=customer.id if customer else None,
            phone=phone,
            contact_name=contact,
            status=status,
            ai_enabled=ai_enabled,
            last_message_at=now,
        )
        db.add(conv)
        db.flush()
        for direction, sender, content in messages:
            db.add(WhatsAppMessage(
                conversation_id=conv.id,
                direction=direction,
                sender=sender,
                content=content,
            ))
        objs.append(conv)
    db.flush()
    return objs


# ─────────────────────────────────────────────
# 9. FIXTURE TODO-EN-UNO (base completa lista)
# ─────────────────────────────────────────────

@pytest.fixture()
def full_dataset(
    tenant, user, customers, products, invoices, production_orders, whatsapp_conversations
):
    """Levanta todo el dataset de una vez. Útil para tests de integración."""
    return {
        "tenant": tenant,
        "user": user,
        "customers": customers,
        "products": products,
        "invoices": invoices,
        "production_orders": production_orders,
        "whatsapp_conversations": whatsapp_conversations,
    }
